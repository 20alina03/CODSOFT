/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alien
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class WeatherApiClient {

    public static final String OPENWEATHERMAP_API_KEY = "3b30d5688b17cd9805130712950b79da"; // Change this to your actual API key

    // Method to fetch weather data from the OpenWeatherMap API
    public static String fetchWeatherData(double lat, double lon) throws IOException {
        String apiUrl = "https://api.openweathermap.org/data/2.5/weather?lat=" + lat + "&lon=" + lon + "&appid=" + OPENWEATHERMAP_API_KEY;

        // Create URL object
        URL url = new URL(apiUrl);

        // Create HttpURLConnection object
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) url.openConnection();

            // Set request method
            connection.setRequestMethod("GET");

            // Set read timeout
            connection.setReadTimeout(5000);

            // Send request
            int responseCode = connection.getResponseCode();

            // Check if request was successful (response code 200)
            if (responseCode == HttpURLConnection.HTTP_OK) {
                // Read response
                StringBuilder response;
                try (BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
                    String inputLine;
                    response = new StringBuilder();
                    while ((inputLine = in.readLine()) != null) {
                        response.append(inputLine);
                    }
                }
                // Return response as string
                return response.toString();
            } else {
                // If request was not successful, print error message
                System.out.println("Error: Unable to fetch weather data. Response code: " + responseCode);
                return null;
            }
        } finally {
            if (connection != null) {
                connection.disconnect();
            }
        }
    }

    // Getter method for OPENWEATHERMAP_API_KEY
    public static String getApiKey() {
        return OPENWEATHERMAP_API_KEY;
    }
}
